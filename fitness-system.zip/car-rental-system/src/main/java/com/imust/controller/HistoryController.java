package com.imust.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.imust.entity.History;
import com.imust.entity.Users;
import com.imust.service.HistoryService;

@Controller
@RequestMapping("/history")
public class HistoryController {
	@Autowired
	private HistoryService historyService;
	
	//获取列表
	@RequestMapping("/showHistory")
	public String showHistory(HttpSession session,Model model) {
		Users user = (Users)session.getAttribute("LogUser");
		List<History> historyList = historyService.getByUser(user.getId());
		model.addAttribute("historyList",historyList);
		return "historyList";
	}
	
}
