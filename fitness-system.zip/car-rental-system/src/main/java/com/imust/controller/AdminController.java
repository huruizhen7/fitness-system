package com.imust.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.imust.entity.Admin;
import com.imust.entity.Car;
import com.imust.entity.History;
import com.imust.entity.Notice;
import com.imust.entity.Order;
import com.imust.entity.Users;
import com.imust.service.AdminService;
import com.imust.service.CarService;
import com.imust.service.HistoryService;
import com.imust.service.NoticeService;
import com.imust.service.OrderService;
import com.imust.service.UserService;

@Controller
@RequestMapping("/admin")
public class AdminController {
	@Autowired
	private AdminService adminService;
	@Autowired
	private CarService carService;
	@Autowired
	private NoticeService noticeService;
	@Autowired
	private OrderService orderService;
	@Autowired
	private UserService userService;
	@Autowired
	private HistoryService historyService;
	
	@RequestMapping("/login")
	public String login(@ModelAttribute("admin") Admin admin,HttpSession session,Model model) {
		
		admin = adminService.login(admin);
		if(admin!=null) {
			session.setAttribute("LogAdmin", admin);
			return "admin/index";
		}else {
			model.addAttribute("msg", "用户名或密码错误");
			return "admin/login";
		}
	}
	
	@RequestMapping("/logout")
	public String logout(HttpSession session) {
		session.removeAttribute("LogAdmin");
		return "admin/login";
	}
	
	//获取管理员列表
	@RequestMapping("/admin-list")
	public String getAllAdmin(Model model) {
		List<Admin> adminList = adminService.getAllAdmin();
		model.addAttribute("adminList",adminList);
		model.addAttribute("adminNum",adminList.size());
		return "admin/admin-list";
	}
	
	@RequestMapping("/findAdminByName")
	public String getByName(@RequestParam("nameTmp")String name,Model model) {
		List<Admin> adminList = adminService.getAdminByName(name);
		model.addAttribute("adminList",adminList);
		model.addAttribute("adminNum",adminList.size());
		model.addAttribute("nameTmp",name);
		return "admin/admin-list";
	}
	
	@RequestMapping("/admin-add")
	public String addAdmin(){
		return "admin/admin-add";
	}

	@ResponseBody
	@RequestMapping("/admin-save")
	public Map<String,String> saveAdmin(@ModelAttribute("admin") Admin admin){
		Map<String,String> map = new HashMap<String,String>();
		map.put("res", "1");
		if(adminService.addAdmin(admin)) {
			map.put("res", "0");
		}
		return map;
	}
	
	//删除管理员账号用过Id
	@ResponseBody
	@RequestMapping("/delAdmin")
	public Map<String,String> delAdmin(@RequestParam("adminId") int id){
		Map<String,String> map = new HashMap<String,String>();
		map.put("res", "1");
		if(adminService.delAdmin(id)) {
			map.put("res", "0");
		}
		return map;
	}
	
	@RequestMapping("/change-info")
	public String editAdmin(@RequestParam("adminId") int id,Model model){
		Admin admin = adminService.getAdminById(id);
		model.addAttribute("admin",admin);
		return "admin/change-info";
	}
	@ResponseBody
	@RequestMapping("/updateAdmin")
	public Map<String,String> updateAdmin(Admin admin){
		Map<String,String> map = new HashMap<String,String>();
		map.put("res", "1");
		if(adminService.updateAdmin(admin)) {
			map.put("res", "0");
		}
		return map;
	}	
	
////////////////////////////////////关于车信息开始
	//获取列表
	@RequestMapping("/car-list")
	public String getAllCar(Model model) {
		List<Car> carList = carService.getAll();
		model.addAttribute("carList",carList);
		model.addAttribute("carNum",carList.size());
		return "car/car-list";
	}
	@RequestMapping("/findCarByKey")
	public String findCarByKey(@RequestParam("keyTmp")String key,Model model) {
		List<Car> carList = carService.getByKey(key);
		model.addAttribute("carList",carList);
		model.addAttribute("carNum",carList.size());
		model.addAttribute("keyTmp",key);
		return "car/car-list";
	}
	@RequestMapping("/car-edit")
	public String editCar(@RequestParam("carId") int id,Model model){
		Car car = carService.getById(id);
		model.addAttribute("car",car);
		return "car/car-edit";
	}
	
	@ResponseBody
	@RequestMapping("/car-update")
	public Map<String,String> saveMessage(@ModelAttribute("car") Car car){
		Map<String,String> map = new HashMap<String,String>();
		map.put("res", "1");
		if(carService.updateCar(car)) {
			map.put("res", "0");
		}
		return map;
	}
	
	//删除
	@ResponseBody
	@RequestMapping("/delCar")
	public Map<String,String> delCar(@RequestParam("carId") int id){
		Map<String,String> map = new HashMap<String,String>();
		map.put("res", "1");
		if(carService.delCar(id)) {
			map.put("res", "0");
		}
		return map;
	}
	//跳转添加页
	@RequestMapping("/car-add")
	public String addCar(){
		return "car/car-add";
	}
	//添加车次
	@ResponseBody
	@RequestMapping("/car-save")
	public Map<String,String> carSave(@ModelAttribute("car") Car car){
		Map<String,String> map = new HashMap<String,String>();
		map.put("res", "1");
		if(carService.addCar(car)) {
			map.put("res", "0");
		}
		return map;
	}
	
	@RequestMapping("/car-qc")
	public String qCar(@RequestParam("orderId") int orderId,Model model){
		Order o = orderService.getById(orderId);
		Car car = carService.getById(o.getCar_id());
		model.addAttribute("car",car);
		model.addAttribute("order",o);
		return "order/car-qc";
	}
//////////////////////关于车信息结束
	
//////////////////////关于公告开始
	
	//获取公告列表
	@RequestMapping("/notice-list")
	public String getAllNotice(Model model) {
		List<Notice> noticeList = noticeService.getAll();
		model.addAttribute("noticeList",noticeList);
		model.addAttribute("noticeNum",noticeList.size());
		return "notice/notice-list";
	}
	
	@RequestMapping("/findNoticeByTitle")
	public String findNoticeByTitle(@RequestParam("titleTmp")String title,Model model) {
		List<Notice> noticeList = noticeService.getByTitle(title);
		model.addAttribute("noticeList",noticeList);
		model.addAttribute("noticeNum",noticeList.size());
		model.addAttribute("titleTmp",title);
		return "notice/notice-list";
	}
	
	@RequestMapping("/notice-add")
	public String addNotice(){
		return "notice/notice-add";
	}
	
	@ResponseBody
	@RequestMapping("/notice-save")
	public Map<String,String> saveNotice(HttpSession session,@ModelAttribute("notice") Notice notice){
		Map<String,String> map = new HashMap<String,String>();
		map.put("res", "1");
		Admin admin = (Admin)session.getAttribute("LogAdmin");
		notice.setAdmin_id(admin.getId());
		notice.setAdmin_name(admin.getName());
		if(noticeService.addNotice(notice)) {
			map.put("res", "0");
		}
		return map;
	}
	
	
	//删除
	@ResponseBody
	@RequestMapping("/delNotice")
	public Map<String,String> delNotce(@RequestParam("noticeId") int id){
		Map<String,String> map = new HashMap<String,String>();
		map.put("res", "1");
		if(noticeService.delNotice(id)) {
			map.put("res", "0");
		}
		return map;
	}
	
	@RequestMapping("/notice-edit")
	public String editNotice(@RequestParam("noticeId") int id,Model model){
		Notice notice = noticeService.getById(id);
		model.addAttribute("notice",notice);
		return "notice/notice-edit";
	}
	//修改
	@ResponseBody
	@RequestMapping("/notice-update")
	public Map<String,String> updateNotice(Notice notice){
		Map<String,String> map = new HashMap<String,String>();
		map.put("res", "1");
		if(noticeService.updateNotice(notice)) {
			map.put("res", "0");
		}
		return map;
	}
	
///////////////////////////////////公告通知结束
	
	
///////////////////////////////////订单管理开始
	//获取列表
	@RequestMapping("/order-list")
	public String getAllOrder(Model model) {
		List<Order> orderList = orderService.getAll();
		model.addAttribute("orderList",orderList);
		model.addAttribute("orderNum",orderList.size());
		return "order/order-list";
	}
	
	@RequestMapping("/findOrderByKey")
	public String findOrderByKey(@RequestParam("keyTmp")String key,Model model) {
		List<Order> orderList = orderService.getByKey(key);
		model.addAttribute("orderList",orderList);
		model.addAttribute("orderNum",orderList.size());
		model.addAttribute("keyTmp",key);
		return "order/order-list";
	}
	
///////////////////////////////////订单管理结束

	
//////////////////////////////////用户管理开始
	//后台模糊查询用户
	@RequestMapping("/findUserByName")
	public String findUserByName(@RequestParam("nameTmp")String name,Model model) {
		List<Users> userList = userService.getByName(name);
		model.addAttribute("userList",userList);
		model.addAttribute("userNum",userList.size());
		model.addAttribute("nameTmp",name);
		return "user/user-list";
	}
	//后台获取用户列表
	@RequestMapping("/user-list")
	public String getAllUser(Model model) {
		List<Users> userList = userService.getAll();
		model.addAttribute("userList",userList);
		model.addAttribute("userNum",userList.size());
		return "user/user-list";
	}
	
	//停用用户账号用过Id
	@ResponseBody
	@RequestMapping("/stopUser")
	public Map<String,String> stopAdmin(@RequestParam("userId") int id){
		Map<String,String> map = new HashMap<String,String>();
		map.put("res", "1");
		if(userService.updateStautsById(id, 1)) {
			map.put("res", "0");
		}
		return map;
	}
	//启用管理员账号用过Id
	@ResponseBody
	@RequestMapping("/startUser")
	public Map<String,String> startAdmin(@RequestParam("userId") int id){
		Map<String,String> map = new HashMap<String,String>();
		map.put("res", "1");
		if(userService.updateStautsById(id, 0)) {
			map.put("res", "0");
		}
		return map;
	}
	////////////////////////////////用户管理结束
	
	////////////////////////////////历史记录管理开始
	//获取公告列表
	@RequestMapping("/history-list")
	public String getAllHistory(Model model) {
		List<History> historyList = historyService.getAll();
		model.addAttribute("historyList",historyList);
		model.addAttribute("historyNum",historyList.size());
		return "history/history-list";
	}
	//模糊查询
	@RequestMapping("/findHistoryByKey")
	public String findHistoryByKey(@RequestParam("keyTmp")String keyTmp,Model model) {
		List<History> historyList = historyService.getByKey(keyTmp);
		model.addAttribute("historyList",historyList);
		model.addAttribute("historyNum",historyList.size());
		model.addAttribute("keyTmp",keyTmp);
		return "history/history-list";
	}
	//我要租车
	@ResponseBody
	@RequestMapping("/wyzc")
	public Map<String,String> saveHistory(@ModelAttribute("history") History history,@RequestParam("orderId")int orderId){
		Map<String,String> map = new HashMap<String,String>();
		map.put("res", "1");
		String zlfs = history.getZlfs();
		double price = Double.parseDouble(zlfs.split("￥")[1]);
		history.setTotal(price*history.getZlzq());
		if(historyService.addHistory(history)) {
			if(orderService.updateStatus(orderId, 1)) {
				map.put("res", "0");
			}
		}
		return map;
	}
	
	//车辆归还
	@ResponseBody
	@RequestMapping("/clgh")
	public Map<String,String> giveCar(@RequestParam("orderId")int orderId){
		Map<String,String> map = new HashMap<String,String>();
		map.put("res", "1");
		Order o = orderService.getById(orderId);
		Users user  = userService.getUserById(o.getUser_id());
		if(carService.updateCarStatus(o.getCar_id(), 0)) {
			if(orderService.updateStatus(orderId, 2)) {
				user.setPoint(user.getPoint()+100);
				if(userService.updateUserPoint(user)) {
					map.put("res", "0");
				}
			}
		}
		return map;
	}
	////////////////////////////////历史记录管理结束
}
