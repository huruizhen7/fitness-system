package com.imust.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import com.imust.entity.History;
@Mapper
public interface HistoryMapper {
	
	//添加信息
	@Insert("insert into History(orderId,total,userId,userName,userPhone,carNum,brand,type,color,"
			+ "insurer,zlfs,zlzq) values(#{orderId},#{total},#{userId},#{userName},#{userPhone},#{carNum},"
			+ "#{brand},#{type},#{color},#{insurer},#{zlfs},#{zlzq})")
    public void insertHistory(History history);
	
	//模糊查询信息
	@Select("select * from History where userName like #{key} or userPhone like #{key} or carNum like #{key}")
	List<History> findByKey(@Param("key") String key);
	
	//查询全部
	@Select("select * from History")
	List<History> findAllHistory();
	
	//查询全部
	@Select("select * from History where userId = #{id}")
	List<History> findHistoryByUser(@Param("id") int id);
	
}
