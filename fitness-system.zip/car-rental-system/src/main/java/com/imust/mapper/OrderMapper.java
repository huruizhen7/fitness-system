package com.imust.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.imust.entity.Order;
@Mapper
public interface OrderMapper {
	

	@Select("select c.carNum,o.code,o.status,o.createDate,o.id,o.car_id,u.name,u.phone,c.color,c.type,c.brand,c.insurer from Orders o,User u,Car c where o.user_id=u.id and o.car_id=c.id order by createDate desc")
	List<Order> findAllOrder();
	
	//查询信息
	@Select("select c.carNum,o.code,o.status,o.createDate,o.id,o.car_id,u.name,u.phone,c.color,c.type,c.brand,c.insurer from Orders o,User u,Car c where o.user_id=u.id and o.car_id=c.id and (u.phone like #{key} or c.brand like #{key} or c.carNum like #{key} or u.name like #{key}) order by createDate desc")
	List<Order> findByKey(@Param("key") String key);
	
	//查询信息
	@Select("select c.carNum,o.code,o.status,o.createDate,o.id,o.car_id,u.name,u.phone,c.color,c.type,c.brand,c.insurer from Orders o,User u,Car c where o.user_id=u.id and o.car_id=c.id and user_id=#{id} order by createDate desc")
	List<Order> findByUserId(@Param("id") int id);
	
	@Select("select o.*,u.name,u.phone from Orders o,User u,Car c where o.user_id=u.id and o.car_id=c.id and o.id=#{id}")
	Order findById(@Param("id") int id);
	//添加信息
	@Insert("insert into Orders(user_id,car_id,code,createDate,status) values(#{user_id},#{car_id},UUID(),SYSDATE(),0)")
    public void insertOrder(Order order);
	
	@Update("update orders set status=#{status} where id=#{id}")
	public void updateStauts(@Param("id") int id,@Param("status") int status);
}
