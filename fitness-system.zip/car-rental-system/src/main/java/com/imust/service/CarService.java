package com.imust.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.imust.entity.Car;
import com.imust.mapper.CarMapper;

@Service
public class CarService {
	
	@Autowired
	private CarMapper carMapper;
	
	//获取全部
	public List<Car> getAll() {
		// TODO Auto-generated method stub
		return carMapper.findAllCar();
	}
	
	//查询
	public Car getById(int id) {
		return carMapper.findCarById(id);
	}
	//通过id修改
	public boolean updateCar(Car car) {
		try {
			carMapper.updateCar(car);
			return true;
		} catch (Exception e) {
			// TODO: handle exception
			return false;
		}
	}
	
	public boolean updateCarStatus(int id,int status) {
		try {
			carMapper.updateCarStauts(id, status);
			return true;
		} catch (Exception e) {
			// TODO: handle exception
			return false;
		}
	}
	
	//后台模糊查询
	public List<Car> getByKey(String tmpKey) {
		String key = "%"+tmpKey+"%";
		return carMapper.findByKey(key);
	}
	
	//前台模糊查询
	public List<Car> getCarByKey(String tmpKey) {
		String key = "%"+tmpKey+"%";
		return carMapper.findCarByKey(key);
	}
	
	//删除
	public boolean delCar(int id) {
		try {
			carMapper.deleteCar(id);
			return true;
		} catch (Exception e) {
			// TODO: handle exception
			return false;
		}
	}
	
	//添加
	public boolean addCar(Car car) {
		try {
			carMapper.insertCar(car);
			return true;
		} catch (Exception e) {
			// TODO: handle exception
			return false;
		}
	}
}
