package com.imust.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.imust.entity.History;
import com.imust.mapper.HistoryMapper;

@Service
public class HistoryService {
	
	@Autowired
	private HistoryMapper historyMapper;
	
	public List<History> getByUser(int id) {
		return historyMapper.findHistoryByUser(id);
	}
		
	//模糊查询
	public List<History> getByKey(String keyTmp) {
		String key = "%"+keyTmp+"%";
		return historyMapper.findByKey(key);
	}
	//获取全部
	public List<History> getAll() {
		// TODO Auto-generated method stub
		return historyMapper.findAllHistory();
	}
	
	//添加
	public boolean addHistory(History history) {
		try {
			historyMapper.insertHistory(history);
			return true;
		} catch (Exception e) {
			// TODO: handle exception
			return false;
		}
	}
}
