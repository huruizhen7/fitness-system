/*
Navicat MySQL Data Transfer

Source Server         : springboot
Source Server Version : 50528
Source Host           : localhost:3306
Source Database       : car-rental-system

Target Server Type    : MYSQL
Target Server Version : 50528
File Encoding         : 65001

Date: 2018-05-03 15:57:13
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for admin
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` int(64) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) DEFAULT NULL,
  `password` varchar(32) DEFAULT NULL,
  `idcard` varchar(18) DEFAULT NULL,
  `sex` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES ('2', '张三', '111111', '152722199403122321', '女');

-- ----------------------------
-- Table structure for car
-- ----------------------------
DROP TABLE IF EXISTS `car`;
CREATE TABLE `car` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `carNum` varchar(32) DEFAULT NULL,
  `type` varchar(8) DEFAULT NULL,
  `color` varchar(8) DEFAULT NULL,
  `brand` varchar(16) DEFAULT NULL,
  `insurer` varchar(32) DEFAULT NULL,
  `year_rental` double(8,2) DEFAULT NULL,
  `month_rental` double(8,2) DEFAULT NULL,
  `week_rental` double(8,2) DEFAULT NULL,
  `day_rental` double(8,2) DEFAULT NULL,
  `status` int(2) DEFAULT '0',
  `address` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of car
-- ----------------------------
INSERT INTO `car` VALUES ('9', '蒙A88999', '轿车', '白色', '奥迪A6L', '平安保险', '12000.00', '3000.00', '1000.00', '300.00', '1', '上海');
INSERT INTO `car` VALUES ('11', '蒙A88966', '轿车', '白色', '宝马760', '平安保险', '12000.00', '3000.00', '1000.00', '300.00', '0', '北京东城区');

-- ----------------------------
-- Table structure for history
-- ----------------------------
DROP TABLE IF EXISTS `history`;
CREATE TABLE `history` (
  `id` int(16) NOT NULL AUTO_INCREMENT,
  `userName` varchar(16) DEFAULT NULL,
  `userPhone` varchar(11) DEFAULT NULL,
  `carNum` varchar(11) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `brand` varchar(16) DEFAULT NULL,
  `type` varchar(16) DEFAULT NULL,
  `color` varchar(16) DEFAULT NULL,
  `insurer` varchar(16) DEFAULT NULL,
  `zlfs` varchar(16) DEFAULT NULL,
  `zlzq` int(12) DEFAULT NULL,
  `total` double(8,2) DEFAULT NULL,
  `userId` int(16) DEFAULT NULL,
  `orderId` int(16) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of history
-- ----------------------------
INSERT INTO `history` VALUES ('5', '李小龙', '13111112222', '蒙A88999', '奥迪A6L', '轿车', '白色', '平安保险', '年租金/￥12000.0', '2', '24000.00', '9', '26');

-- ----------------------------
-- Table structure for notice
-- ----------------------------
DROP TABLE IF EXISTS `notice`;
CREATE TABLE `notice` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `title` varchar(32) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `createDate` date DEFAULT NULL,
  `admin_id` int(32) DEFAULT NULL,
  `admin_name` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of notice
-- ----------------------------
INSERT INTO `notice` VALUES ('1', '停用通知公告', '555555', '2018-03-24', '1', 'admin');
INSERT INTO `notice` VALUES ('4', '交通规则', '213123132131312312313', '2018-03-24', '1', 'admin');
INSERT INTO `notice` VALUES ('7', '北京直通车', '2313123萨达萨达是 爱的阿斯顿阿斯顿阿斯顿撒大苏打收到的', '2018-03-29', '1', 'admin');
INSERT INTO `notice` VALUES ('8', '高速封路', '啊实打实安德森是大神大神大大撒的啊收到阿三是', '2018-03-13', '1', 'admin');
INSERT INTO `notice` VALUES ('9', '3242', '23423423423', '2018-05-02', '2', '张三');

-- ----------------------------
-- Table structure for orders
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `user_id` int(32) DEFAULT NULL,
  `car_id` int(32) DEFAULT NULL,
  `createDate` date DEFAULT NULL,
  `code` varchar(64) DEFAULT NULL,
  `status` int(2) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of orders
-- ----------------------------
INSERT INTO `orders` VALUES ('26', '9', '9', '2018-05-03', '93990683-4e8c-11e8-8e7e-00059a3c7a00', '1');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) DEFAULT NULL,
  `password` varchar(32) DEFAULT NULL,
  `phone` varchar(11) DEFAULT NULL,
  `idCard` varchar(18) DEFAULT NULL,
  `stauts` int(2) DEFAULT NULL,
  `age` int(8) DEFAULT '18',
  `sex` varchar(2) DEFAULT NULL,
  `drive_age` varchar(255) DEFAULT NULL,
  `point` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('9', '李小龙', '1234', '13111112222', '152722199403121111', '0', '24', '男', '5年', null);
