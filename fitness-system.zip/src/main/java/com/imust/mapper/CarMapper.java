package com.imust.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.imust.entity.Car;
@Mapper
public interface CarMapper {
	

	@Select("select * from Car")
	List<Car> findAllCar();
	
	@Select("select distinct  c.* from car c,browses b where c.status=0 and c.id = b.carId and b.userId = #{id} ORDER BY b.createTime DESC  limit 7")
	List<Car> findAi(@Param("id") int id);
	
	@Select("select * from Car where status=0 ORDER BY sales DESC  limit 7")
	List<Car> getSalesCars();
	
	@Select("select * from Car where id=#{id}")
	Car findCarById(@Param("id") int id);
	
	//查询信息
	@Select("select * from Car where address like #{key} or type like #{key} or color like #{key} or brand like #{key}")
	List<Car> findByKey(@Param("key") String key);
	
	@Select("select * from Car where status=0 and( address like #{key} or type like #{key} or color like #{key} or brand like #{key})")
	List<Car> findCarByKey(@Param("key") String key);
	
	//添加信息
	@Insert("insert into Car(address,carNum,type,color,brand,"
			+ "insurer,year_rental,month_rental,week_rental,day_rental,url)"
			+ " values(#{address},#{carNum},#{type},#{color},"
			+ "#{brand},#{insurer},#{year_rental},#{month_rental},#{week_rental},#{day_rental},#{url})")
    public void insertCar(Car car);
	
	@Insert("insert into browses(userId,carId,createtime) values(#{userId},#{carId},now())")
	public void browseAdd(@Param("userId")int userId,@Param("carId")int carId);
	
	//删除信息
	@Delete("delete from Car where id=#{id}")
	public void deleteCar(int id);
	
	
	//修改信息
	@Update("update Car set url=#{url},carNum=#{carNum},type=#{type},address=#{address},"
			+ "color=#{color},brand=#{brand},insurer=#{insurer},"
			+ "year_rental=#{year_rental},day_rental=#{day_rental},month_rental=#{month_rental},week_rental=#{week_rental} where id=#{id}")
	public void updateCar(Car car);
	
	@Update("update Car set sales=(sales + 1) where id=#{id}")
	public void updateSales(@Param("id") int id);
	
	@Update("update Car set status=#{status} where id=#{id}")
	public void updateCarStauts(@Param("id") int id,@Param("status") int status);
}
