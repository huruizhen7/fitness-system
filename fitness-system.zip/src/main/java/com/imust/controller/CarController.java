package com.imust.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.imust.entity.Car;
import com.imust.entity.Notice;
import com.imust.entity.Order;
import com.imust.entity.Users;
import com.imust.service.CarService;
import com.imust.service.OrderService;

@Controller
@RequestMapping("/car")
public class CarController {
	@Autowired
	private CarService carService;
	@Autowired
	private OrderService orderService;
	
	@RequestMapping("/car-select")
	public String getCarByKey(@RequestParam("key")String key,Model model) {
		List<Car> carList = carService.getCarByKey(key);
		model.addAttribute("carList",carList);
		model.addAttribute("carNum",carList.size());
		return "list";
	}
	
	@RequestMapping("/car-detail")
	public String showCar(HttpSession session,@RequestParam("id") int id,Model model){
		Car car = carService.getById(id);
		model.addAttribute("car",car);
		Users user = (Users)session.getAttribute("LogUser");
		if(user!=null) {
			carService.browseAdd(user.getId(), id);
		}
		return "car-detail";
	}
	
	@RequestMapping("/yy-car")
	public String yyCar(HttpSession session,@RequestParam("carId") int id){
		Users user = (Users)session.getAttribute("LogUser");
		Order order = new Order();
		order.setCar_id(id);
		order.setUser_id(user.getId());
		if(orderService.addOrder(order)) {
			if(carService.updateCarStatus(id, 1)) {
				return "redirect:/order/showOrder";
			}
		}
		
		return "404";
	}
}
