package com.imust.entity;

public class Car {
	private int id;
	private String carNum;//车牌
	private String type;//类型
	private String color;//颜色
	private String brand;//品牌型号
	private String insurer;//保险公司
	private String status;//保险公司
	private String address;//所在地
	private String url;//图片路径
	private double year_rental ;//年租金
	private double month_rental ;//月租金
	private double week_rental ;//周租金
	private double day_rental ;//日租金
	private int sales ;//日租金
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCarNum() {
		return carNum;
	}
	public void setCarNum(String carNum) {
		this.carNum = carNum;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getInsurer() {
		return insurer;
	}
	public void setInsurer(String insurer) {
		this.insurer = insurer;
	}
	public double getYear_rental() {
		return year_rental;
	}
	public void setYear_rental(double year_rental) {
		this.year_rental = year_rental;
	}
	public double getMonth_rental() {
		return month_rental;
	}
	public void setMonth_rental(double month_rental) {
		this.month_rental = month_rental;
	}
	public double getWeek_rental() {
		return week_rental;
	}
	public void setWeek_rental(double week_rental) {
		this.week_rental = week_rental;
	}
	public double getDay_rental() {
		return day_rental;
	}
	public void setDay_rental(double day_rental) {
		this.day_rental = day_rental;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getSales() {
		return sales;
	}
	public void setSales(int sales) {
		this.sales = sales;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	
}
